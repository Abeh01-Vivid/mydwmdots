void newterm(const Arg *);
