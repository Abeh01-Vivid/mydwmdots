return {
  -- File tree
  {
    "nvim-tree/nvim-tree.lua",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    config = function()
      require("nvim-tree").setup({
        view = { width = 30 },
        renderer = { group_empty = true },
        filters = { dotfiles = false },
      })
    end,
  },
  -- Which-key
  {
    "folke/which-key.nvim",
    event = "VeryLazy",
    config = function()
      require("which-key").setup()
    end,
  },
  -- Autopairs
  {
    "windwp/nvim-autopairs",
    event = "InsertEnter",
    config = function()
      require("nvim-autopairs").setup()
    end,
  },
  -- Git signs
  {
    "lewis6991/gitsigns.nvim",
    config = function()
      require("gitsigns").setup()
    end,
  },
  -- Comment toggle
  {
    "numToStr/Comment.nvim",
    config = function()
      require("Comment").setup()
    end,
  },
  -- Indent guides
  {
    "lukas-reineke/indent-blankline.nvim",
    main = "ibl",
    config = function()
      require("ibl").setup()
    end,
  },
  -- Dashboard
  {
    "nvimdev/dashboard-nvim",
    event = "VimEnter",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    config = function()
      require("dashboard").setup({
        theme = "hyper",
        config = {
          header = {
            "                                        ",
            " ███╗   ██╗███████╗ ██████╗ ██╗   ██╗ ",
            " ████╗  ██║██╔════╝██╔═══██╗██║   ██║ ",
            " ██╔██╗ ██║█████╗  ██║   ██║██║   ██║ ",
            " ██║╚██╗██║██╔══╝  ██║   ██║╚██╗ ██╔╝ ",
            " ██║ ╚████║███████╗╚██████╔╝ ╚████╔╝  ",
            " ╚═╝  ╚═══╝╚══════╝ ╚═════╝   ╚═══╝   ",
            "                                        ",
          },
          shortcut = {
            { desc = "  Files", group = "Label", action = "Telescope find_files", key = "f" },
            { desc = "  Grep",  group = "Label", action = "Telescope live_grep",  key = "g" },
            { desc = "  Quit",  group = "Label", action = "qa",                   key = "q" },
          },
        },
      })
    end,
  },
}
